The Soical Media Icons are known to get deleted alot so just be careful when uploading upload on a alt account
and do not name them by their names when uploaded you will 100% get banned/warned.